"use client";

import Link from "next/link";

export default function RegisterPage() {
  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Register</h1>
      <form className="space-y-4">
        <input
          type="text"
          placeholder="Name"
          className="w-full p-3 border rounded-xl"
        />
        <input
          type="email"
          placeholder="Email"
          className="w-full p-3 border rounded-xl"
        />
        <input
          type="password"
          placeholder="Password"
          className="w-full p-3 border rounded-xl"
        />
        <button
          type="submit"
          className="w-full p-3 bg-gradient-to-r from-[#B260E6] to-[#ED84A5] text-white rounded-xl font-medium"
        >
          Sign Up
        </button>
      </form>
      <p className="mt-4 text-center text-gray-500">
        Already have an account?{" "}
        <Link href="/auth/login" className="text-[#B260E6] font-medium">
          Sign In
        </Link>
      </p>
    </div>
  );
}
