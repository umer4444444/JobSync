__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/2e53d83b67e8e752.js",
  "static/chunks/turbopack-7a0cd1aa63fc76a5.js"
])
