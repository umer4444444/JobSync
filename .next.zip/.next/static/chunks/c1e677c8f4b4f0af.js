__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/2e53d83b67e8e752.js",
  "static/chunks/turbopack-6f86dd5d1e7fc8e3.js"
])
