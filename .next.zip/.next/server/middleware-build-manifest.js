globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/2e53d83b67e8e752.js",
      "static/chunks/turbopack-6f86dd5d1e7fc8e3.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/2e53d83b67e8e752.js",
      "static/chunks/turbopack-7a0cd1aa63fc76a5.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ad7a72571a912c6a.js",
    "static/chunks/a1dcc8326efcdb85.js",
    "static/chunks/6aedb6af4d3017e4.js",
    "static/chunks/7880f8283a6f3daf.js",
    "static/chunks/turbopack-c5b0572ae5e25ebd.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];