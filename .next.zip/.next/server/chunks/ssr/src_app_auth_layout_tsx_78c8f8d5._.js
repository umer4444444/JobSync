module.exports=[42050,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}}];

//# sourceMappingURL=src_app_auth_layout_tsx_78c8f8d5._.js.map