var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__930efee1._.js")
R.c("server/chunks/[root-of-the-server]__ed940978._.js")
R.c("server/chunks/[root-of-the-server]__c9082154._.js")
R.m(9606)
R.m(30450)
module.exports=R.m(30450).exports
