var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__dc1042b8._.js")
R.c("server/chunks/[root-of-the-server]__d1ac37e2._.js")
R.m(96331)
R.m(6706)
module.exports=R.m(6706).exports
