__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/f43c831e69b592d0.js",
  "static/chunks/turbopack-402c44e92774beb3.js"
])
