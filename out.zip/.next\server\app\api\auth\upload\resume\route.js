var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/upload/resume/route.js")
R.c("server/chunks/[root-of-the-server]__3faaeab9._.js")
R.c("server/chunks/[root-of-the-server]__d1ac37e2._.js")
R.m(39200)
R.m(74013)
module.exports=R.m(74013).exports
