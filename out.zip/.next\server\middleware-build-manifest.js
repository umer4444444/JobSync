globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/f43c831e69b592d0.js",
      "static/chunks/turbopack-402c44e92774beb3.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/f43c831e69b592d0.js",
      "static/chunks/turbopack-cd86e716e13e3ab4.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4c791b400ebbf74c.js",
    "static/chunks/c1915865246da9ba.js",
    "static/chunks/ad485e1ef0aa584e.js",
    "static/chunks/7880f8283a6f3daf.js",
    "static/chunks/turbopack-dd59f9f4bbc36fbd.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];